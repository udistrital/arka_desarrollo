<?php
ini_set("soap.wsdl_cache_enabled", "0");
 
//iniciar cliente soap
//escribir la dirección donde se encuentra el servicio
$cliente = new SoapClient("http://10.20.0.38/ws_arka_android/servicio.php?wsdl");
 
//establecer parametros de envío
$params = array("usuario" => 4, "contrasenna" => "lll");
 
//llamar a la función raiz cuadrada
//y guardar el resultado
$result = $cliente->__SoapCall('login', $params);
 
//imprimir primer resultado
echo $result;

$params = array("name" => "Emmanuel");

//llamar a la función raiz cuadrada
//y guardar el resultado
$result = $cliente->__SoapCall('gethelloworld', $params);

//imprimir primer resultado
echo $result;

$params = array();

$result = $cliente->__SoapCall('consultar_dependencias', $params);

//imprimir primer resultado
echo $result[1];
echo $result[2];
echo $result[3];
echo $result[4];
echo $result[5];
echo $result[6];
echo $result[7];
echo $result[8];
echo $result[9];
echo $result[10];
echo $result[11];
echo $result[10];

$params = array("dependencia" => "1");

$result = $cliente->__SoapCall('consultar_dependencias', $params);

echo $result[1]."Aquiiiiiiiiiiiiiiiiiiiiii";
echo $result[2];
echo $result[3];

echo "________________________________________________________________";
 
$params = array("documento_funcionario" => "1");

$result = $cliente->__SoapCall('consultar_elementos', $params);

 echo "<h1>Lista de Usuarios</h1>";  
 
  //Contar la cantidad de elemenos del arreglo recibido
  $limite= count($result);
 
  //Imprimir la lista de usuarios recibida
  for ($i=0;$i<$limite; $i++){
    $id=$result[$i]->id_elemento;
    $nombre=$result[$i]->descripcion;
    $serie=$result[$i]->serie;
    
 
    echo "Id: <strong>$id</strong> - Nombre: <strong>$nombre</strong> - serie: <strong>$serie</strong><br/>";
  }


?>
