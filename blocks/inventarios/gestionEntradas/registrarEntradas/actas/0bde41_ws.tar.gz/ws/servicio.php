<?php
// librería nusoap
require_once ('lib/nusoap.php');
require_once ('funcion.php');

// instanciamos un nuevo servidor soap
$server = new soap_server ();

// Namespace
$ns = "urn:arka";

// asignamos el nombre y namespace al servicio
$server->configureWSDL ( "arka", $ns );

// registramos la primera función
$server->register ( 'login', array (
		'usuario' => 'xsd:int',
		'contrasenna' => 'xsd:string' 
), // tipo de dato recibido
array (
		'return' => 'xsd:string' 
), $ns, false, 'rpc', // tipo documento
'literal', // tipo codificación
'Documentacion' ); // documentación

$server->register ( 'gethelloworld', array (
		'name' => 'xsd:string' 
), array (
		'return' => 'xsd:string' 
), $ns, false, 'rpc', // tipo documento
'literal', // tipo codificación
'Documentacion' ); // documentación
                   
// Con esta forma se determina que se va a retornar un arreglo
$server->wsdl->addComplexType ( "ArrayOfString", 
		"complexType", 
		"array", 
		"", 
		"SOAP-ENC:Array",
		 array (), 
		array (
		array (
				"ref" => "SOAP-ENC:arrayType",
				"wsdl:arrayType" => "xsd:string[]" 
		) 
		),
		 "xsd:string" );

$server->register ( 'consultar_funcionarios', 
		array ('dependencia' => 'xsd:int'),
		array ("return" => "tns:ArrayOfString"),
		$ns, false, 'rpc', // tipo documento
		'literal', // tipo codificación
		'Documentacion' ); // documentación

$server->register ( 'consultar_dependencias',
		array (),
		array ("return" => "tns:ArrayOfString"),
		$ns, false, 'rpc', // tipo documento
		'literal', // tipo codificación
		'Documentacion' ); // documentación


//------------------------


$server->wsdl->addComplexType(
		'Estructura',
		'complexType',
		'struct',
		'all',
		'',
		array(
				'id_elemento' => array('name' => 'id_elemento', 'type' => 'xsd:int'),
				'descripcion'=>array('name' => 'descripcion', 'type' => 'xsd:string'),
				'marca' => array('name' => 'marca', 'type' => 'xsd:string'),
				'nivel' => array('name' => 'nivel', 'type' => 'xsd:string'),
				'placa'=>array('name' => 'placa', 'type' => 'xsd:string'),
				'serie' => array('name' => 'serie', 'type' => 'xsd:string'),
				'valor'=>array('name' => 'valor', 'type' => 'xsd:string'),
				'subtotal_sin_iva' => array('name' => 'subtotal_sin_iva', 'type' => 'xsd:string'),
				'total_iva'=>array('name' => 'total_iva', 'type' => 'xsd:string'),
				'total_iva_con' => array('name' => 'total_iva_con', 'type' => 'xsd:string'),				
		)
);

//configurar arreglo de la estructura
$server->wsdl->addComplexType(
		'ArregloDeEstructuras',
		'complexType',
		'array',
		'sequence',
		'http://schemas.xmlsoap.org/soap/encoding/:Array',
		array(),
		array(
				array('ref' => 'http://schemas.xmlsoap.org/soap/encoding/:arrayType',
						'wsdl:arrayType' => 'tns:Estructura[]'
				)
		),'tns:Estructura');


$server->register ( 'consultar_elementos',
		array ('nombre_funcionario' => 'xsd:string'),
		array ("return" => "tns:ArregloDeEstructuras"),
		$ns, false, 'rpc', // tipo documento
		'literal', // tipo codificación
		'Documentacion' ); // documentación


                   
// Ver más tipos de datos
                   // http://dcx.sybase.com/1200/en/dbprogramming/datatypes-http.html
                   
// Ver más sobre documento/codificación
                   // http://www.ibm.com/developerworks/webservices/library/ws-whichwsdl/
                   
// Establecer servicio
if (isset ( $HTTP_RAW_POST_DATA )) {
	$input = $HTTP_RAW_POST_DATA;
} else {
	$input = implode ( "rn", file ( 'php://input' ) );
}

$server->service ( $input );
?>